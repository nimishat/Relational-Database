# Professor insert statements

DELETE FROM STUDENTDEPT;
DELETE FROM COURSEDEPT;
DELETE FROM DEPTCHAIR;
DELETE FROM ENROLL; 
DELETE FROM ADVISOR;
DELETE FROM CLASS;
DELETE FROM COURSE;
DELETE FROM STUDENT;
DELETE FROM PROFESSOR;
DELETE FROM DEPARTMENT;


INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('SJ001', 'Information Systems', 'Professor', 'Jones' , 'Samuel' , 'L' , 'SJones@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('NS001', 'Data Analytics', 'Professor', 'Smith' , 'Nancy' , 'P' , 'NSmith@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('RA001', 'Microbiology', 'Adjunct', 'Adams' , 'Robert' , 'R' , 'RAdams@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('BB001', 'Thermodynamics', 'Professor', 'Brooks' , 'Bradford' , 'C' , 'BBrooks@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('SM001', 'Discrete Math', 'Adjunct', 'McDonald' , 'Susan' , 'W' , 'SMcDonald@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('SW001', 'Choreography', 'Professor', 'Winsor' , 'Stephen' , 'A' , 'SWinsor@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('TA001', 'Macroeconomics', 'Professor', 'Anthony' , 'Todd' , 'T' , 'TAnthony@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('JW001', 'Child Development', 'Professor', 'Walker' , 'Joanne' , 'L' , 'JWalker@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('TH001', 'Statics', 'Professor', 'Hastings' , 'Timothy' , '' , 'THastings@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('MY001', 'Quantum Mechanics', 'Professor', 'Young' , 'Margaret' , 'J' , 'MYoung@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('CM001', 'Software Engineering', 'Professor', 'MacNamara' , 'Christine' , 'F' , 'CMacNamara@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('DW001', 'Voice Coaching', 'Professor', 'Winsor' , 'Deborah' , '' , 'DWinsor@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('HB001', 'Technology in Education', 'Professor', 'Brown' , 'Harold' , 'R' , 'HBrown@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('CN001', 'Genetics', 'Professor', 'Noble' , 'Charles' , 'E' , 'CNoble@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('FL001', 'Statistical Mechanics', 'Professor', 'Lawton' , 'Francis' , 'X' , 'FLawton@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('PH001', 'Hydraulics and Hydrology', 'Adjunct', 'Hohl' , 'Patrick' , '' , 'PHohl@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('KY001', 'Aerodynamics', 'Professor', 'Yang' , 'Kim' , '' , 'KYang@trinity.edu');

INSERT INTO PROFESSOR (PROFID, PROFSPECIALTY, PROFRANK, PROFLNAME, PROFFNAME, PROFINITIAL, PROFEMAIL)
VALUES ('JS002', 'Cosmology', 'Adjunct', 'Santiago' , 'Jose' , 'M' , 'JSantiago@trinity.edu');

#  Department insert statements 
INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('MSIS', 'MSIS');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('BIO', 'Biology');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('PHY', 'Physics');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('MKT', 'Marketing');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('ECO', 'Economics');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('CHE', 'Chemistry');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('DAN', 'Dance');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('MUS', 'Music');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('AER', 'Aerospace');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('CE', 'Civil Engineering');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('CS', 'Computer Science');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('AM', 'Applied Mathematics');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('EE', 'Elementary Education');

INSERT INTO DEPARTMENT (DEPTID, DEPTNAME)
VALUES ('SE', 'Special Education');

# Student table insert statements 
INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('PP001', 'Pierce', 'Paul', 'A', 'ppierce@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('AA001', 'Adams', 'Abigail', 'W', 'aadams@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('WS001', 'Smithson', 'William', 'P', 'wsmithson@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('AB001', 'Bonner', 'Allison', 'W', 'abonner@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('MB001', 'Brady', 'Marcia', '', 'mbrady@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('KN001', 'Nelson', 'Kenneth', 'A', 'knelson@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('CA001', 'Alexander', 'Constance', 'C', 'calexander@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('TN001', 'Nguyen', 'Trin', '', 'tnguyen@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('SB001', 'Brandt', 'Stephen', 'R', 'sbrandt@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('JE001', 'Espanet', 'Jesse', '', '');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('JE002', 'Espanet', 'Jesse', '', '');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('EL001', 'Lawton', 'Eleanor', '', 'elawton@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('RK001', 'King', 'Robert', 'L', 'rking@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('RM001', 'McNamara', 'Richard', '', 'rmcnamara@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('LC0001', 'Chin', 'lori', '', 'lchin@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('JM001', 'Martinez', 'Jose', '', 'jmartinez@trinity.edu');

INSERT INTO STUDENT (StudentID, StudentLName, StudentFName, StudentInitial, StudentEmail)
VALUES ('MB002', 'Brown', 'Marcus', 'L', '');

# Course Insert statements 
INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('MGT105', 'Intro to Information Systems', 'Lecture', '3');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('MGT475', 'Strategic Marketing', 'Lecture', '4');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('ENG210', 'Engineering Mechanics I', 'Lab', '3');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('ENG320', 'Electric Circuits', 'Lab', '4');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('EDU117', 'Educational Equity and the Law', 'Lecture', '3');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('EDU256', 'Education and Religion', 'Lecture', '3');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('MATH300', 'Statistics', 'Lecture', '4');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('MATH325', 'Calculus II', 'Lecture', '4');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('SCI110', 'Physics I', 'Lab', '3');

INSERT INTO COURSE (CourseID, CourseTitle, CourseDescription, CourseCredits)
VALUES ('SCI415', 'Thermodynamics', 'Lab', '4');

# Class insert statements 
INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL001', '1', 'MWF', '8:00-9:00', 'MGT105', 'SJ001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL002', '2', 'TThu', '1:30-3:00', 'MGT105', 'NS001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL003', '1', 'MWF', '1:00-2:00', 'MGT475', 'SJ001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL004', '1', 'MWF', '11:00-12:00', 'ENG210', 'KY001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL005', '2', 'TThu', '11:30-1:00', 'ENG210', 'KY001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL006', '3', 'W', '6:00-9:00', 'ENG210', 'BB001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL007', '1', 'TTh', '8:30-11:00', 'MATH300', 'SM001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL008', '1', 'MWF', '10:00-11:00', 'MATH325', 'MY001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL009', '1', 'M', '6:00-9:00', 'SCI110', 'FL001');

INSERT INTO CLASS (ClassID, ClassSection, ClassDays, ClassTime, CourseID, ProfID)
VALUES ('CL010', '1', 'Th', '6:00-9:00', 'SCI415', 'MY001');

# Enroll Insert Statements
 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
 VALUES ('CL001', 'PP001', '2020-03-09', '', 'MGT105');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL002', 'PP001', '2020-01-04', '', 'MGT105');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL003', 'PP001', '2020-01-21', '', 'MGT475');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL009', 'AA001', '2020-03-12', '', 'SCI110');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL010', 'AA001', '2020-02-29', '', 'SCI415');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL004', 'WS001', '2020-02-15', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL005', 'AB001', '2020-01-17', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL006', 'AB001', '2020-03-31', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL008', 'AB001', '2020-02-02', '', 'MATH325');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL009', 'JE001', '2020-01-20', '', 'SCI110');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL020', 'JE002', '2020-03-31', '', 'SCI415');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL001', 'JE002', '2020-01-15', '', 'MGT105');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL004', 'LC001', '2020-01-05', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL008', 'JM001', '2020-03-17', '', 'MATH325');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL009', 'MB002', '2020-03-15', '', 'SCI110');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL006', 'MB001', '2020-04-01', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL005', 'RK002', '2020-02-12', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL006', 'RK002', '2020-04-05', '', 'ENG210');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL003', 'KN001', '2020-03-03', '', 'MGT475');

 INSERT INTO ENROLL (ClassID, StudentID, EnrollmentDate, Grade, CourseID)
VALUES ('CL010', 'CA001', '2020-02-12', '', 'SCI415');

# DeptChair Insert Statements
INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('MSIS', 'SJ001');

INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('BIO', '');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('PHY', 'JS001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('MKT', 'NS001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('ECO', '');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('CHE', 'MY001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('DAN', 'SW001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('MUS', 'DW001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('AER', 'TH001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('CE', '');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('CS', '');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('AM', 'SM001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('EE', 'JW001');

  INSERT INTO DEPTCHAIR (DEPTID, PROFESSORID)
VALUES ('SE', 'JW001');

# Advisor Insert Statements 
INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('PP001', 'NS001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('AA001', 'CN001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('WS001', 'TA001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('AB001', '');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('MB001', 'JW001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('KN001', 'SJ001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('CA001', 'NS001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('TN001', 'CM001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('SB001', 'TH001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('JE001', '');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('JE002', 'SW001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('EL001', 'MY001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('RK001', '');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('RK002', 'CM001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('RM001', 'HB001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('LC001', '');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('JM001', 'HB001');

 INSERT INTO ADVISOR (StudentID, ProfessorID)
VALUES ('MB002', '');

# StudentDept insert statements 
INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('PP001', 'MSIS');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('AA001', 'BIO');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('WS001', 'ECO');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('AB001', 'CS');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('MB001', 'SE');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('KN001', '');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('CA001', 'MSIS');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('TN001', 'CS');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('SB001', '');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('JE001', 'PHY');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('JE002', 'DAN');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('EL001', '');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('RK001', 'PHY');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('RK002', 'CS');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('RM001', 'EE');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('LC001', 'MUS');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('JM001', 'EE');

INSERT INTO STUDENTDEPT (StudentID, DeptID)
VALUES ('MB002', 'MKT');

# CourseDept Insert Statements 
INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('MGT105', 'MSIS');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('MGT475', 'MKT');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('ENG210', 'AER');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('ENG320', 'CE');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('EDU117', 'EE');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('EDU256', 'EE');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('MATH300', 'AM');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('MATH325', 'AM');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('SCI110', 'PHY');

INSERT INTO COURSEDEPT (CourseID, DeptID)
VALUES ('SCI415', 'PHY');

